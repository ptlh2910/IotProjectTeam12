const util = require('util')
const mysql = require('mysql')
const db = require('../db');
const mgr = require('../../Manager');

module.exports = {
    get: (req, res) => {
        console.log(1);

        // response
        res.send("Success");
    },
    post: (req, res) => {
        let data = req.body;
        let id = data.id;
        let val = data.val;
        console.log("Switch ", id, " val", val);
        mgr.set(id, val);
        // response
        res.send("Success");
    },
}
