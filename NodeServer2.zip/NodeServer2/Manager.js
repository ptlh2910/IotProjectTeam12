class Manager{
    constructor() {
        this.NUMBER_OF_SWITCH = 10;
        this.last = 0;
        this.state = Array(5).fill(0);
    }

    get(id) {
        return this.state[id];
    }

    set(id, val) {
        this.state[id] = val;
    }

    print() {
        console.log(123);
    }
}

var mgr = new Manager();
module.exports = mgr;